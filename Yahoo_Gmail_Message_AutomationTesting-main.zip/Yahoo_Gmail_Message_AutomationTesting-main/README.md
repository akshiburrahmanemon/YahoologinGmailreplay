# Yahoo_Gmail_Message_AutomotionTesting
Yahoo login and send a message to a gmail then validated it send or not and logout.Gmail login to check message. 
